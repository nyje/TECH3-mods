# XPro v1.1.0
[![download](https://img.shields.io/github/tag/BrunoMine/xpro.svg?style=flat-square&label=release)](https://github.com/BrunoMine/xpro/archive/v1.1.0.zip)
[![git](https://img.shields.io/badge/git-project-green.svg?style=flat-square)](https://github.com/BrunoMine/xpro)
[![forum](https://img.shields.io/badge/minetest-mod-green.svg?style=flat-square)](https://forum.minetest.net/viewtopic.php?f=9&t=20499&p=325793#p325793)
[![bower](https://img.shields.io/badge/bower-mod-green.svg?style=flat-square)](https://minetest-bower.herokuapp.com/mods/xpro)

## Descrição _Description_
Sistema de niveis e experiencia

## Requisitos _(Requirements)_
* Minetest 0.4.17 ou superior
* Mod default
* Mod sfinv
* Mod intllib (opicional)

## Licença _(License)_
Veja LICENSE.txt para informações detalhadas da licença LGPL 3.0

### Autores do código fonte
Originalmente por BrunoMine, Bruno Borges <borgesdossantosbruno@gmail.com> (LGPL 3.0)

### Autores de mídias (texturas, modelos and sons)

Todas que não estão descritas aqui são de autoria de
BrunoMine, Bruno Borges <borgesdossantosbruno@gmail.com> (CC BY-SA 3.0)

